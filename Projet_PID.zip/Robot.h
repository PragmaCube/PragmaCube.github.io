class Robot
{
    const float kMaxSpeed = 4.2; // 4.2 m.s^-1
    const float kMaxAcceleration = 20;
    const float kMass = 40; // 40 kg
    const float kStaticFrictionCoefficient = 1.0;
    const float kG = 9.807;

    float mLastInput;
    float mInput;

    float mPosition;    
    float mSpeed;
    float mAcceleration;
    float mAccelerationWheels;

public:
    Robot();
    ~Robot();

    float getMaxSpeed();
    float getAcceleration();
    float getSpeed();
    float getPosition();

    void setPosition(float);
    
    void move(float);
};

float clamp(float, float, float);