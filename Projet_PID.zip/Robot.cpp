#include "Robot.h"

#include <cmath>
#include <iostream>

float clamp(float iNbr, float iMin, float iMax)
{
    if (iNbr > iMax)
    {
        return iMax;
    }

    if (iNbr < iMin)
    {
        return iMin;
    }

    return iNbr;
}

Robot::Robot()
{
    mSpeed = 0;
    mAcceleration = 0;
    mLastInput = 0;
}

Robot::~Robot() { }

float Robot::getMaxSpeed()
{
    return kMaxSpeed;
}

float Robot::getAcceleration()
{
    return mAcceleration;
}

float Robot::getSpeed()
{
    return mSpeed;
}

float Robot::getPosition()
{
    return mPosition;
}

void Robot::setPosition(float iPosition)
{
    mPosition = iPosition;
}

void Robot::move(float iPower)
{
    iPower = clamp(iPower, -1, 1);

    if (std::abs(mAcceleration - iPower * kMaxAcceleration) < kMaxAcceleration / 25.0)
    {
        mAcceleration = iPower * kMaxAcceleration;
    }

    else if (mAcceleration > iPower * kMaxAcceleration)
    {
        mAcceleration -= kMaxAcceleration / 25.0;
    }

    else
    {
        mAcceleration += kMaxAcceleration / 25.0;
    }

    if (std::abs(mAcceleration) > kStaticFrictionCoefficient * kG)
    {
        if (iPower * kMaxAcceleration > 0)
        {
            mSpeed = mSpeed + 0.02 * (mAcceleration - kStaticFrictionCoefficient * kG);
        }

        else
        {
            mSpeed = mSpeed + 0.02 * (mAcceleration + kStaticFrictionCoefficient * kG);
        }
    }

    else
    {
        if (std::abs(mSpeed) < kMaxSpeed / 25.0)
        {
            mSpeed = 0;
        }

        else
        {
            if (mSpeed > 0)
            {
                mSpeed -= kMaxSpeed / 25.0;
            }

            else
            {
                mSpeed += kMaxSpeed / 25.0;
            }
        }
    }

    mSpeed = clamp(mSpeed, -kMaxSpeed, kMaxSpeed);

    mPosition = 0.02 * mSpeed + mPosition;

    // Max acceleration reached in 0.5s if full power

    mLastInput = iPower;
}