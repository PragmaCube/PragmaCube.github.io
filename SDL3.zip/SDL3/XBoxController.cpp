#include "XBoxController.h"

XBoxController::XBoxController() { }

XBoxController::XBoxController(SDL_Event * iEvent)
{
    if (iEvent->type == SDL_EVENT_JOYSTICK_ADDED)
    {
        if (mJoystick == nullptr)
        {
            mJoystick = SDL_OpenJoystick(iEvent->jdevice.which);

            if (!mJoystick)
            {
                SDL_Log("Failed to open joystick ID %u: %s", (unsigned int) iEvent->jdevice.which, SDL_GetError());
            }

            else
            {
                mNbrAxis = SDL_GetNumJoystickAxes(mJoystick);
                mPort = int(iEvent->jdevice.which);
            }
        }
    }
    
    else if (iEvent->type == SDL_EVENT_JOYSTICK_REMOVED)
    {
        if (mJoystick)
        {
            SDL_CloseJoystick(mJoystick);
            mJoystick = nullptr;
            mPort = -1;
            mNbrAxis = 0;
        }
    }
}

XBoxController::~XBoxController() { }

double XBoxController::GetLeftX()
{
    if (mJoystick != nullptr && mNbrAxis == 6)
    {
        return (((double) SDL_GetJoystickAxis(mJoystick, 0)) / 32767.0f);
    }

    return 0;
}

double XBoxController::GetRightX()
{
    if (mJoystick != nullptr && mNbrAxis == 6)
    {
        return (((double) SDL_GetJoystickAxis(mJoystick, 2)) / 32767.0f);
    }

    return 0;
}

double XBoxController::GetLeftY()
{
    if (mJoystick != nullptr && mNbrAxis == 6)
    {
        return (((double) SDL_GetJoystickAxis(mJoystick, 1)) / 32767.0f);
    }

    return 0;
}

double XBoxController::GetRightY()
{
    if (mJoystick != nullptr && mNbrAxis == 6)
    {
        return (((double) SDL_GetJoystickAxis(mJoystick, 4)) / 32767.0f);
    }

    return 0;
}

bool XBoxController::GetAButton()
{
    if (mJoystick != nullptr && mNbrAxis == 6)
    {
        return SDL_GetJoystickButton(mJoystick, 0);
    }

    return false;
}

bool XBoxController::GetBButton()
{
    if (mJoystick != nullptr && mNbrAxis == 6)
    {
        return SDL_GetJoystickButton(mJoystick, 1);
    }

    return false;
}

bool XBoxController::GetXButton()
{
    if (mJoystick != nullptr && mNbrAxis == 6)
    {
        return SDL_GetJoystickButton(mJoystick, 2);
    }

    return false;
}

bool XBoxController::GetYButton()
{
    if (mJoystick != nullptr && mNbrAxis == 6)
    {
        return SDL_GetJoystickButton(mJoystick, 3);
    }

    return false;
}

bool XBoxController::GetLeftBumperButton()
{
    if (mJoystick != nullptr && mNbrAxis == 6)
    {
        return SDL_GetJoystickButton(mJoystick, 4);
    }

    return false;
}

bool XBoxController::GetRightBumperButton()
{
    if (mJoystick != nullptr && mNbrAxis == 6)
    {
        return SDL_GetJoystickButton(mJoystick, 5);
    }

    return false;
}