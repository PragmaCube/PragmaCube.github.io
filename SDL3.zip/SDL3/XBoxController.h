#include <SDL3/SDL.h>

class XBoxController
{
    SDL_Joystick * mJoystick = nullptr;
    int mPort = -1;
    int mNbrAxis = 0;

public:
    XBoxController();
    XBoxController(SDL_Event * iEvent);
    ~XBoxController();

    double GetLeftX();
    double GetRightX();
    double GetLeftY();
    double GetRightY();

    double GetLeftTriggerAxis();
    double GetRightTriggerAxis();

    bool GetAButton();
    bool GetBButton();
    bool GetXButton();
    bool GetYButton();

    bool GetLeftBumperButton();
    bool GetRightBumperButton();
};